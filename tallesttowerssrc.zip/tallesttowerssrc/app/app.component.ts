// Harpreet Singh 
// Student Id - 991714737
// Import necessary modules and components
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title(title: any) {
    throw new Error('Method not implemented.');
  }
  // Declare an array of tower data
  towers = [
    {
      rank: 1,
      name: 'Tokyo Skytree',
      city: 'Tokyo',
      height: 634,
      imageUrl: 'https://ejd.songho.ca/syst24444/towers/tokyo-skytree.jpg'
    },
    {
      rank: 2,
      name: 'Canton Tower',
      city: 'Guangzhou',
      height: 604,
      imageUrl: 'https://ejd.songho.ca/syst24444/towers/canton-tower.jpg'
    },
    {
      rank: 3,
      name: 'CN Tower',
      city: 'Toronto',
      height: 553,
      imageUrl: 'https://ejd.songho.ca/syst24444/towers/cn-tower.jpg'
    }
  ];
}
