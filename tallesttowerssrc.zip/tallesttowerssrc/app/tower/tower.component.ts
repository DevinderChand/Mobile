// Harpreet Singh 
// Student Id - 991714737
// Import necessary modules and components
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-tower',
  templateUrl: './tower.component.html',
  styleUrls: ['./tower.component.css']
})
export class TowerComponent {
  // Declare input property to receive tower data from parent component
  @Input() towerData: any;
}
