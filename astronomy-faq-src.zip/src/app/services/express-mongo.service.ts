import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ExpressMongoService {

  private baseUrl = 'http://127.0.0.1:8887';

  constructor(private http: HttpClient) { }

  createDatabase(params: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/createDatabase`, params);
  }

  batchLoadItems(items: any[]): Observable<any> {
    return this.http.post(`${this.baseUrl}/batchLoadItems`, { items });
  }

  deleteAllItems(): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteAllItems`);
  }

  retrieveAllItems(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/retrieveAllItems`);
  }

  updateItem(item: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/updateItem/${item._id}`, item);
  }

  deleteItem(id: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteItem/${id}`);
  }

  addNewItem(item: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/addNewItem`, item);
  }
}
