import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ExpressMongoService } from '../../services/express-mongo.service';
import { AlertController, ToastController } from '@ionic/angular';

@Component({
  selector: 'app-update',
  templateUrl: 'update.page.html',
  styleUrls: ['update.page.scss'],
})
export class UpdatePage implements OnInit {
  item: any = { question: '', answer: '' };
  toastMessage: string = '';
  toastColor: string = 'success';

  constructor(
    private expressMongoService: ExpressMongoService,
    private router: Router,
    private alertController: AlertController,
    private toastController: ToastController
  ) {}

  ngOnInit() {
    if (history.state.item) {
      this.item = history.state.item;
    }
  }

  async updateItem() {
    try {
      await this.expressMongoService.updateItem(this.item).toPromise();
      this.toastMessage = 'Item updated successfully';
      this.toastColor = 'success';
      await this.showToast();
      this.router.navigate(['/listing']);
    } catch (error) {
      this.toastMessage = 'Failed to update item';
      this.toastColor = 'danger';
      await this.showToast();
    }
  }

  async deleteItem() {
    const alert = await this.alertController.create({
      header: 'Confirm Delete',
      message: 'Are you sure you want to delete this item?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel'
        },
        {
          text: 'Delete',
          handler: async () => {
            try {
              await this.expressMongoService.deleteItem(this.item._id).toPromise();
              this.toastMessage = 'Item deleted successfully';
              this.toastColor = 'success';
              await this.showToast();
              this.router.navigate(['/listing']);
            } catch (error) {
              this.toastMessage = 'Failed to delete item';
              this.toastColor = 'danger';
              await this.showToast();
            }
          }
        }
      ]
    });
    await alert.present();
  }

  async addNewItem() {
    try {
      await this.expressMongoService.addNewItem(this.item).toPromise();
      this.toastMessage = 'Item added successfully';
      this.toastColor = 'success';
      await this.showToast();
      this.router.navigate(['/listing']);
    } catch (error) {
      this.toastMessage = 'Failed to add new item';
      this.toastColor = 'danger';
      await this.showToast();
    }
  }

  async showToast() {
    const toast = await this.toastController.create({
      message: this.toastMessage,
      duration: 2000,
      color: this.toastColor,
      position: 'top'
    });
    await toast.present();
  }
}
