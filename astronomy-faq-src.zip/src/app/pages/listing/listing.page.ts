import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ExpressMongoService } from '../../services/express-mongo.service';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-listing',
  templateUrl: 'listing.page.html',
  styleUrls: ['listing.page.scss'],
})
export class ListingPage implements OnInit {
  items: any[] = []; // Ensure items is always an array

  constructor(
    private expressMongoService: ExpressMongoService,
    private router: Router,
    private toastController: ToastController
  ) {}

  async ngOnInit() {
    try {
      const data = await this.expressMongoService.retrieveAllItems().toPromise();
      this.items = data || []; // Assign an empty array if data is undefined
      await this.presentToast('Items retrieved successfully');
    } catch (error) {
      await this.presentToast('Failed to retrieve items');
    }
  }

  viewItem(item: any) {
    this.router.navigate(['/update'], { state: { item } });
  }

  async presentToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
      color: 'success',
      position: 'top'
    });
    await toast.present();
  }
}
