import { Component } from '@angular/core';
import { ExpressMongoService } from '../../services/express-mongo.service';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-main',
  templateUrl: 'main.page.html',
  styleUrls: ['main.page.scss'],
})
export class MainPage {
  databaseName: string = '';
  collectionName: string = '';
  isDatabaseCreated: boolean = false;
  toastMessage: string = '';
  toastColor: string = 'success';

  constructor(private expressMongoService: ExpressMongoService, private toastController: ToastController) {}

  async createDatabase() {
    try {
      await this.expressMongoService.createDatabase({ dbName: this.databaseName, collectionName: this.collectionName }).toPromise();
      this.isDatabaseCreated = true;
      this.toastMessage = 'Database created successfully';
      this.toastColor = 'success';
      await this.showToast();
    } catch (error) {
      this.toastMessage = 'Failed to create database';
      this.toastColor = 'danger';
      await this.showToast();
    }
  }

  async batchLoadItems() {
    const items = [
      { question: 'What is astronomy?', answer: 'The study of celestial objects.' },
      { question: 'What are stars?', answer: 'Luminous celestial bodies.' },
      { question: 'What is a black hole?', answer: 'A region of spacetime exhibiting strong gravitational effects.' },
      { question: 'What is the Milky Way?', answer: 'The galaxy that contains our Solar System.' },
      { question: 'What are comets?', answer: 'Icy bodies that release gas or dust.' },
    ];
    try {
      await this.expressMongoService.batchLoadItems(items).toPromise();
      this.toastMessage = 'Batch items loaded successfully';
      this.toastColor = 'success';
      await this.showToast();
    } catch (error) {
      this.toastMessage = 'Failed to load batch items';
      this.toastColor = 'danger';
      await this.showToast();
    }
  }

  async deleteAllItems() {
    try {
      await this.expressMongoService.deleteAllItems().toPromise();
      this.toastMessage = 'All items deleted successfully';
      this.toastColor = 'success';
      await this.showToast();
    } catch (error) {
      this.toastMessage = 'Failed to delete all items';
      this.toastColor = 'danger';
      await this.showToast();
    }
  }

  async showToast() {
    const toast = await this.toastController.create({
      message: this.toastMessage,
      duration: 2000,
      color: this.toastColor,
      position: 'top'
    });
    await toast.present();
  }
}
