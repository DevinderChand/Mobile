const express = require('express');
const app = express();
const port = 8887;
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');

app.use(bodyParser.json());
app.use(cors());

// Define the schema for the FAQ collection
const faqSchema = new mongoose.Schema({
  question: { type: String, required: true },
  answer: { type: String, required: true }
});

// Create the model for the FAQ collection
const Faq = mongoose.model('Faq', faqSchema);

// Connect to the default astronomyFAQ database
mongoose.connect('mongodb://localhost:27017/astronomyFAQ')
  .then(() => console.log('Connected to astronomyFAQ MongoDB'))
  .catch(err => console.error('Could not connect to MongoDB:', err));

// Endpoint to create a new database with the provided name
app.post('/createDatabase', (req, res) => {
  const { dbName } = req.body;

  if (!dbName) {
    return res.status(400).send({ message: 'Database name is required' });
  }

  // Create a new connection to the specified database
  const newDbConnection = mongoose.createConnection(`mongodb://localhost:27017/${dbName}`);

  newDbConnection.once('open', () => {
    console.log(`Connected to ${dbName} database`);

    // Define a simple schema and model for the new database
    const simpleSchema = new mongoose.Schema({
      name: { type: String, required: true }
    });

    const SimpleModel = newDbConnection.model('SimpleCollection', simpleSchema);

    // Insert a sample document to trigger database creation
    const sampleDocument = new SimpleModel({ name: 'Sample Name' });
    sampleDocument.save()
      .then(() => res.send({ message: `Database '${dbName}' and collection created successfully` }))
      .catch(err => res.status(500).send({ message: err.message }));
  });

  newDbConnection.on('error', err => {
    console.error('Connection error:', err);
    res.status(500).send({ message: 'Could not connect to database' });
  });
});

// Other CRUD operations for the astronomyFAQ database
app.post('/batchLoadItems', (req, res) => {
  Faq.insertMany(req.body.items)
    .then(() => res.send({ message: 'Items added successfully' }))
    .catch(err => res.status(500).send({ message: err.message }));
});

app.delete('/deleteAllItems', (req, res) => {
  Faq.deleteMany({})
    .then(() => res.send({ message: 'All items deleted successfully' }))
    .catch(err => res.status(500).send({ message: err.message }));
});

app.get('/retrieveAllItems', (req, res) => {
  Faq.find({})
    .then(items => res.send(items))
    .catch(err => res.status(500).send({ message: err.message }));
});

app.put('/updateItem/:id', (req, res) => {
  Faq.findByIdAndUpdate(req.params.id, req.body, { new: true })
    .then(item => res.send(item))
    .catch(err => res.status(500).send({ message: err.message }));
});

app.delete('/deleteItem/:id', (req, res) => {
  Faq.findByIdAndDelete(req.params.id)
    .then(() => res.send({ message: 'Item deleted successfully' }))
    .catch(err => res.status(500).send({ message: err.message }));
});

app.post('/addNewItem', (req, res) => {
  const newItem = new Faq(req.body);
  newItem.save()
    .then(() => res.send({ message: 'Item added successfully' }))
    .catch(err => res.status(500).send({ message: err.message }));
});

// Start the Express server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
