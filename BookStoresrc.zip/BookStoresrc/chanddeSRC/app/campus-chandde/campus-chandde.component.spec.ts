import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CampusChanddeComponent } from './campus-chandde.component';

describe('CampusChanddeComponent', () => {
  let component: CampusChanddeComponent;
  let fixture: ComponentFixture<CampusChanddeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CampusChanddeComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CampusChanddeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
