// campus-chandde.component.ts

import { Component, Input } from '@angular/core';
import { CampusData } from '../chanddeInterface';


@Component({
  selector: 'app-campus-chandde',
  templateUrl: './campus-chandde.component.html',
  styleUrls: ['./campus-chandde.component.css']
})
export class CampusChanddeComponent {
  @Input() campusChanddenumber: CampusData[] = [];
  selectedCampus: string = '';
  addressOutput: string = '';

  onSelectCampus() {
    if (this.selectedCampus) {
      const selectedCampusData = this.campusChanddenumber.find(campus => campus.campus === this.selectedCampus);

      if (selectedCampusData) {
        // Build the output using template literals
        this.addressOutput = `Sheridan College - ${selectedCampusData.campus} Campus:
                             ${selectedCampusData.street}, ${selectedCampusData.city}`;
      } else {
        this.addressOutput = 'Campus information not available';
      }
    } else {
      this.addressOutput = 'Please select a campus';
    }
  }
}
