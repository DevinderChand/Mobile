// campus-chandde.module.ts

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatSelectModule } from '@angular/material/select'; // Add this line

import { CampusChanddeComponent } from './campus-chandde.component';

@NgModule({
  declarations: [
    CampusChanddeComponent
  ],
  imports: [
    CommonModule,
    MatSelectModule // Add this line
  ],
  exports: [
    CampusChanddeComponent
  ]
})
export class CampusChanddeModule { }
