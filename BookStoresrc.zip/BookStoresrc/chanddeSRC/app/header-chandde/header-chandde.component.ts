import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-header-chandde',
  standalone: true,
  imports: [],
  templateUrl: './header-chandde.component.html',
  styleUrl: './header-chandde.component.css'
})
export class HeaderChanddeComponent {
  @Input() chanddeMyData: any;
}
