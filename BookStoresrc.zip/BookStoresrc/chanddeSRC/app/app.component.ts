// app.component.ts

import { Component } from '@angular/core';
import * as data from '../assets/data/Assignment02.json';
import { A2Personal, CampusData, MyBook } from './chanddeInterface';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title: string = "A2 Winter 2024"; // Assuming you want to set a title property
  chanddePersonal: A2Personal = data.a2Personal;
  chanddeBooks: MyBook[] = data.businessBooks; // Adjusted to use the correct data property
  chanddeCampus: CampusData[] = data.campusData;
}
