// app.module.ts

import { MatTabsModule } from '@angular/material/tabs';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HeaderChanddeComponent } from "./header-chandde/header-chandde.component";
import { BooksChanddeModule } from "./books-chandde/books-chandde.module";
import { CampusChanddeModule } from "./campus-chandde/camous-chandde.module";
import { FooterChanddeComponent } from "./footer-chandde/footer-chandde.component";

@NgModule({
    declarations: [
        AppComponent
    ],
    providers: [],
    bootstrap: [AppComponent],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        FormsModule,
        MatTabsModule,
        MatInputModule,
        MatTableModule,
        MatIconModule,
        HeaderChanddeComponent,
        BooksChanddeModule,
        CampusChanddeModule,
        FooterChanddeComponent
    ]
})
export class AppModule { }
