// books-chandde.module.ts

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table'; // Add this line

import { BooksChanddeComponent } from './books-chandde.component';

@NgModule({
  declarations: [
    BooksChanddeComponent
  ],
  imports: [
    CommonModule,
    MatTableModule // Add this line
  ],
  exports: [
    BooksChanddeComponent
  ]
})
export class BooksChanddeModule { }
