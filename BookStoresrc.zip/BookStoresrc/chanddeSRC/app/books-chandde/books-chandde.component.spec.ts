import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BooksChanddeComponent } from './books-chandde.component';

describe('BooksChanddeComponent', () => {
  let component: BooksChanddeComponent;
  let fixture: ComponentFixture<BooksChanddeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BooksChanddeComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BooksChanddeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
