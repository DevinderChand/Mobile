import { Component, Input } from '@angular/core';
import { MyBook } from '../chanddeInterface';

@Component({
  selector: 'app-books-chandde',
  templateUrl: './books-chandde.component.html',
  styleUrls: ['./books-chandde.component.css']
})
export class BooksChanddeComponent {
  @Input() myBookschanddenumber: MyBook[] = [];
}
