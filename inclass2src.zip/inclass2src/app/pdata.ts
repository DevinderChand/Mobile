export interface Pdata {
    fName: string;
    lName: string;
    nName: string;
    }