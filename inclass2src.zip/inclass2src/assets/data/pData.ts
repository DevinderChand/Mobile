import { Pdata } from '../../app/pdata';
export const PDATA: Pdata = {
 fName: 'Andy',
 lName: 'Pak',
 nName: 'Unknown'
};