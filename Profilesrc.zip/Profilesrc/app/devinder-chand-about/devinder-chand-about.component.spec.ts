import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DevinderchandAboutComponent } from './devinder-chand-about.component';

describe('DevinderChandAboutComponent', () => {
  let component: DevinderchandAboutComponent;
  let fixture: ComponentFixture<DevinderchandAboutComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DevinderchandAboutComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DevinderchandAboutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
