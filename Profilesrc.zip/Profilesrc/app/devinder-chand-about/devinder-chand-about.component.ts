// devinderchand-about.component.ts

import { Component, Input } from '@angular/core';
import { DevinderchandPersonal } from '../Classes/classDevinderchand';

@Component({
  selector: 'app-devinderchand-about',
  templateUrl: './devinder-chand-about.component.html',
  styleUrls: ['./devinder-chand-about.component.css']
})
export class DevinderchandAboutComponent {
  @Input()
  devinderchandMe!: DevinderchandPersonal;
}
