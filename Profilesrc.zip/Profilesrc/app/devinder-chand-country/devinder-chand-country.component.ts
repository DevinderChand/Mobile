// devinderchand-country.component.ts

import { Component, Input } from '@angular/core';
import { DevinderchandCountry } from '../Classes/classDevinderchand';

@Component({
  selector: 'app-devinderchand-country',
  templateUrl: './devinder-chand-country.component.html',
  styleUrls: ['./devinder-chand-country.component.css']
})
export class DevinderchandCountryComponent {
  @Input()
  devinderchandData!: DevinderchandCountry;
}
