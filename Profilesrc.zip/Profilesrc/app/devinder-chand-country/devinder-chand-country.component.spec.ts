import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DevinderchandCountryComponent } from './devinder-chand-country.component';

describe('DevinderChandCountryComponent', () => {
  let component: DevinderchandCountryComponent;
  let fixture: ComponentFixture<DevinderchandCountryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DevinderchandCountryComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DevinderchandCountryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
