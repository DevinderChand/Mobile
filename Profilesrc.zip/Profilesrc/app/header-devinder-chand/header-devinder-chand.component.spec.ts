import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderDevinderchandComponent } from './header-devinder-chand.component';

describe('HeaderDevinderChandComponent', () => {
  let component: HeaderDevinderchandComponent;
  let fixture: ComponentFixture<HeaderDevinderchandComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HeaderDevinderchandComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(HeaderDevinderchandComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
