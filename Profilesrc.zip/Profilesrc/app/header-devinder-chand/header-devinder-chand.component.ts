// header-devinderchand.component.ts

import { Component, Input } from '@angular/core';
import { DatePipe } from '@angular/common';
import { DevinderchandPersonal } from '../Classes/classDevinderchand';

@Component({
  selector: 'app-header-devinderchand',
  templateUrl: './header-devinder-chand.component.html',
  styleUrls: ['./header-devinder-chand.component.css'],
  providers: [DatePipe]  // Add DatePipe to the providers
})
export class HeaderDevinderchandComponent {
  @Input()
  devinderchandChild!: DevinderchandPersonal;
  currentDate: Date = new Date();

}
