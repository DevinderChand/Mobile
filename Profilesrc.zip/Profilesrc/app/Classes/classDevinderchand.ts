// classDevinderchand.ts

export class DevinderchandPersonal {
    devinderchandName!: string;
    devinderchandID!: string;
    devinderchandLoginName!: string;
    devinderchandEmail!: string;
    devinderchandCampus!: string;
    devinderchandImageName!: string;
  }
  
  export class DevinderchandCountry {
    devinderchandCountry!: string;
    devinderchandCountryID!: number;
    devinderchandCountryCapital!: string;
    devinderchandCountrySalary!: number;
    devinderchandCountryFlagImage!: string;
  }
  