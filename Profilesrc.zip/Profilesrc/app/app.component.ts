// app.component.ts

import { Component } from '@angular/core';
import { DevinderchandCountry, DevinderchandPersonal } from './Classes/classDevinderchand';
// Update with your actual model file path

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'A1devinderChand';

  PERdevinderchand: DevinderchandPersonal = {
    devinderchandName: 'Devinder Chand',
    devinderchandLoginName: 'DevinderChand',
    devinderchandEmail: 'chandde@sheridancollege.ca',
    devinderchandCampus: 'Trafalgar',
    devinderchandImageName: '../images/Profile.jpg',
    devinderchandID: '991717596'
  };

  CTRYdevinderchand: DevinderchandCountry = {
    devinderchandCountry: 'India',
    devinderchandCountryCapital: 'New Delhi',
    devinderchandCountrySalary: 7130,
    devinderchandCountryFlagImage: '../images/India.jpeg',
    devinderchandCountryID: 356
  };

  actualStudentNumber = 991717596; // Replace with the actual student number to compare
  actualCountryCode = 356; // Replace with the actual country code to compare
}
