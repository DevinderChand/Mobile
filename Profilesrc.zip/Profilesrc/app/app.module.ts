import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { HeaderDevinderchandComponent } from './header-devinder-chand/header-devinder-chand.component';
import { DevinderchandAboutComponent } from './devinder-chand-about/devinder-chand-about.component';
import { DevinderchandCountryComponent } from './devinder-chand-country/devinder-chand-country.component';
import { DevinderchandPicsComponent } from './devinder-chand-pics/devinder-chand-pics.component';
import { CommonModule, DatePipe } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatIconModule } from '@angular/material/icon';
import { MatTabsModule } from '@angular/material/tabs';
@NgModule({
  declarations: [
    
    AppComponent,
    HeaderDevinderchandComponent,
    DevinderchandAboutComponent,
    DevinderchandCountryComponent,
    DevinderchandPicsComponent
  ],
  imports: [
    CommonModule,
    BrowserAnimationsModule,
    BrowserModule,
    AppRoutingModule,
    MatTabsModule,
    MatIconModule,
  ],
  providers: [DatePipe,
    provideClientHydration(),
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
