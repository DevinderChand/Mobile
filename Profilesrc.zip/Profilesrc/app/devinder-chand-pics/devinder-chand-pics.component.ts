// devinderchand-pics.component.ts

import { Component, Input } from '@angular/core';
import { DevinderchandCountry, DevinderchandPersonal } from '../Classes/classDevinderchand';

@Component({
  selector: 'app-devinderchand-pics',
  templateUrl: './devinder-chand-pics.component.html',
  styleUrls: ['./devinder-chand-pics.component.css']
})
export class DevinderchandPicsComponent {
  @Input()
  devinderchandMe!: DevinderchandPersonal;
  @Input()
  devinderchandData!: DevinderchandCountry;
  actualStudentNumber: number = 991722956;
  actualCountryCode: number = 356;
}
