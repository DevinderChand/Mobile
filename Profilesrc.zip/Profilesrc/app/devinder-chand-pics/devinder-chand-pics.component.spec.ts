import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DevinderchandPicsComponent } from './devinder-chand-pics.component';

describe('DevinderChandPicsComponent', () => {
  let component: DevinderchandPicsComponent;
  let fixture: ComponentFixture<DevinderchandPicsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DevinderchandPicsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DevinderchandPicsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
