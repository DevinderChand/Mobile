// src/app/app-routing.module.ts
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AceChanddeComponent } from './ace-chandde/ace-chandde.component';
import { KingChanddeComponent } from './king-chandde/king-chandde.component';
import { QueenChanddeComponent } from './queen-chandde/queen-chandde.component';
import { JackChanddeComponent } from './jack-chandde/jack-chandde.component';

const routes: Routes = [
  { path: 'ace', component: AceChanddeComponent },
  { path: 'king', component: KingChanddeComponent },
  { path: 'queen', component: QueenChanddeComponent },
  { path: 'jack', component: JackChanddeComponent },
  { path: '', redirectTo: '/ace', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
