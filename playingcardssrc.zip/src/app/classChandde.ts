// src/app/classChandde.ts
export class A3ClassChandde {
    fullNameYOURSheridanID: string = 'DevinderChand';
    idYOURSheridanID: string = '991717596';
    emailYOURSheridanEmail: string = 'chandde@sheridancollege.ca';
    loginYOURSheridanLogin: string = 'chandde';
  }
  