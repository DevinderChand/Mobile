// src/app/header-chandde/header-chandde.component.ts
import { Component, Input, OnInit } from '@angular/core';
import { A3ClassChandde } from '../classChandde';

@Component({
  selector: 'app-header-chandde',
  templateUrl: './header-chandde.component.html',
  styleUrls: ['./header-chandde.component.scss']
})
export class HeaderChanddeComponent implements OnInit {
  @Input()
  HFchandde!: A3ClassChandde;

  constructor() { }

  ngOnInit(): void {
  }

}
