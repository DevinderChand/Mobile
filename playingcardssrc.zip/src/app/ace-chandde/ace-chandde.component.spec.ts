import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AceChanddeComponent } from './ace-chandde.component';

describe('AceChanddeComponent', () => {
  let component: AceChanddeComponent;
  let fixture: ComponentFixture<AceChanddeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AceChanddeComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AceChanddeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
