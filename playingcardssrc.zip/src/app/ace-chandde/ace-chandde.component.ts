// src/app/ace-chandde/ace-chandde.component.ts
import { Component, OnInit } from '@angular/core';
import { CardChanddeService } from '../card-chandde.service';

@Component({
  selector: 'app-ace-chandde',
  templateUrl: './ace-chandde.component.html',
  styleUrls: ['./ace-chandde.component.scss']
})
export class AceChanddeComponent implements OnInit {
  title: string = 'Ace of Spades';
  suit: string = 'spades';
  image: string = 'assets/images/ace.png';
  degree: number = 60;
  zero: number = 0;
  currentRotation: number = 0; // Track current rotation

  constructor(private cardService: CardChanddeService) { }

  ngOnInit(): void {
  }

  rotateCard() {
    this.currentRotation += this.degree; // Increment rotation
    this.cardService.chanddeChanges('ace', this.currentRotation);
  }

  resetCard() {
    this.currentRotation = 0; // Reset rotation
    this.cardService.chanddeChanges('ace', this.currentRotation);
  }
}
