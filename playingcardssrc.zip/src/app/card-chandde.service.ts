// src/app/card-chandde.service.ts
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CardChanddeService {

  constructor() { }

  chanddeChanges(cardId: any, degrees: number) {
    const cardElement = document.getElementById(cardId);
    if (cardElement) {
      cardElement.style.transform = `rotate(${degrees}deg)`;
      cardElement.style.transitionDuration = '3s';
    }
  }
}
