// src/app/app.component.ts
import { Component } from '@angular/core';
import { A3ClassChandde } from './classChandde';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  profileChandde: A3ClassChandde = new A3ClassChandde();
  HFchandde: A3ClassChandde = new A3ClassChandde();
}
