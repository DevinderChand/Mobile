// src/app/jack-chandde/jack-chandde.component.ts
import { Component, OnInit } from '@angular/core';
import { CardChanddeService } from '../card-chandde.service';

@Component({
  selector: 'app-jack-chandde',
  templateUrl: './jack-chandde.component.html',
  styleUrls: ['./jack-chandde.component.scss']
})
export class JackChanddeComponent implements OnInit {
  title: string = 'Jack of Clubs';
  suit: string = 'clubs';
  image: string = 'assets/images/jack.png';
  degree: number = 280;
  zero: number = 0;
  currentRotation: number = 0;

  constructor(private cardService: CardChanddeService) { }

  ngOnInit(): void {
  }

  rotateCard() {
    this.currentRotation += this.degree;
    this.cardService.chanddeChanges('jack', this.currentRotation);
  }

  resetCard() {
    this.currentRotation = 0;
    this.cardService.chanddeChanges('jack', this.currentRotation);
  }
}
