import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JackChanddeComponent } from './jack-chandde.component';

describe('JackChanddeComponent', () => {
  let component: JackChanddeComponent;
  let fixture: ComponentFixture<JackChanddeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [JackChanddeComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(JackChanddeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
