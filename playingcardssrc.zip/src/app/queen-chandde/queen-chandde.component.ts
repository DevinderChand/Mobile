// src/app/queen-chandde/queen-chandde.component.ts
import { Component, OnInit } from '@angular/core';
import { CardChanddeService } from '../card-chandde.service';

@Component({
  selector: 'app-queen-chandde',
  templateUrl: './queen-chandde.component.html',
  styleUrls: ['./queen-chandde.component.scss']
})
export class QueenChanddeComponent implements OnInit {
  title: string = 'Queen of Hearts';
  suit: string = 'hearts';
  image: string = 'assets/images/queen.png';
  degree: number = 240;
  zero: number = 0;
  currentRotation: number = 0;

  constructor(private cardService: CardChanddeService) { }

  ngOnInit(): void {
  }

  rotateCard() {
    this.currentRotation += this.degree;
    this.cardService.chanddeChanges('queen', this.currentRotation);
  }

  resetCard() {
    this.currentRotation = 0;
    this.cardService.chanddeChanges('queen', this.currentRotation);
  }
}
