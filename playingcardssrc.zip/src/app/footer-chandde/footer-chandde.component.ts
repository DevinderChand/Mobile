// src/app/footer-chandde/footer-chandde.component.ts
import { Component, Input, OnInit } from '@angular/core';
import { A3ClassChandde } from '../classChandde';

@Component({
  selector: 'app-footer-chandde',
  templateUrl: './footer-chandde.component.html',
  styleUrls: ['./footer-chandde.component.scss']
})
export class FooterChanddeComponent implements OnInit {
  @Input()
  HFchandde!: A3ClassChandde;

  constructor() { }

  ngOnInit(): void {
  }

}
