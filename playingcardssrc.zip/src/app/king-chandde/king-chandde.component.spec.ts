import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KingChanddeComponent } from './king-chandde.component';

describe('KingChanddeComponent', () => {
  let component: KingChanddeComponent;
  let fixture: ComponentFixture<KingChanddeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [KingChanddeComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(KingChanddeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
