// src/app/king-chandde/king-chandde.component.ts
import { Component, OnInit } from '@angular/core';
import { CardChanddeService } from '../card-chandde.service';

@Component({
  selector: 'app-king-chandde',
  templateUrl: './king-chandde.component.html',
  styleUrls: ['./king-chandde.component.scss']
})
export class KingChanddeComponent implements OnInit {
  title: string = 'King of Diamonds';
  suit: string = 'diamonds';
  image: string = 'assets/images/king.png';
  degree: number = 120;
  zero: number = 0;
  currentRotation: number = 0;

  constructor(private cardService: CardChanddeService) { }

  ngOnInit(): void {
  }

  rotateCard() {
    this.currentRotation += this.degree;
    this.cardService.chanddeChanges('king', this.currentRotation);
  }

  resetCard() {
    this.currentRotation = 0;
    this.cardService.chanddeChanges('king', this.currentRotation);
  }
}
