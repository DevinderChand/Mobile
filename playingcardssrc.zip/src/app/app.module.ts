import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { HeaderChanddeComponent } from './header-chandde/header-chandde.component';
import { FooterChanddeComponent } from './footer-chandde/footer-chandde.component';
import { AceChanddeComponent } from './ace-chandde/ace-chandde.component';
import { KingChanddeComponent } from './king-chandde/king-chandde.component';
import { QueenChanddeComponent } from './queen-chandde/queen-chandde.component';
import { JackChanddeComponent } from './jack-chandde/jack-chandde.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatGridListModule } from '@angular/material/grid-list';

@NgModule({
  declarations: [
    AppComponent,
    HeaderChanddeComponent,
    FooterChanddeComponent,
    AceChanddeComponent,
    KingChanddeComponent,
    QueenChanddeComponent,
    JackChanddeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatGridListModule,
    
  ],
  providers: [
    provideClientHydration(),
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
