import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title(title: any) {
    throw new Error('Method not implemented.');
  }
  dataUrl = 'assets/data/Assignment04.json';
  jsonData: any;
  currentDate: Date = new Date();
  formGroup!: FormGroup;
  formSubmitted: boolean = false;
  outputData: string = '';

  constructor(private http: HttpClient, private fb: FormBuilder) {}

  ngOnInit() {
    this.http.get(this.dataUrl).subscribe(
      (data: any) => {
        this.jsonData = data;
        this.initializeFormGroup();
      },
      (error) => {
        console.error('Error loading JSON data:', error);
        // Handle error loading JSON data
      }
    );
  }

  initializeFormGroup() {
    this.formGroup = this.fb.group({
      id: [this.jsonData?.controlDefaults?.ID || ''],
      firstName: [this.jsonData?.controlDefaults?.controlFirst || ''],
      lastName: [this.jsonData?.controlDefaults?.controlLast || ''],
      size: [this.jsonData?.controlDefaults?.controlSize || ''],
      colour: [this.jsonData?.controlDefaults?.controlColour || ''],
      includeCampusName: false,
      includeSheridanLogo: false,
      startDate: [this.currentDate]
    });
  }

  onSubmit() {
    const formData = this.formGroup.value;
    let inclusions = '';
    if (formData.includeCampusName) {
      inclusions += 'Campus Name ';
    }
    if (formData.includeSheridanLogo) {
      inclusions += 'Sheridan Logo';
    }
    this.outputData = `${formData.id}  / ${formData.firstName} ${formData.lastName}\n` +
                   `Ordered ${formData.size} size shirt in colour ${formData.colour}\n` +
                   `Includes: ${inclusions}\n` +
                   `Ordered: ${formData.startDate.toLocaleDateString()}`;
    console.log(this.outputData);
    this.formSubmitted = true;
  }
}
