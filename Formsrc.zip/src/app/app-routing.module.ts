import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AdmissionFormComponent } from './chandde-admission-form/chandde-admission-form.component';
import { FilledInfoComponent } from './chandde-filled-info/chandde-filled-info.component';

const routes: Routes = [
  { path: '', component: AdmissionFormComponent },
  { path: 'submit', component: FilledInfoComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
