import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderChanddeComponent } from './header-chandde/header-chandde.component';
import { FooterChanddeComponent } from './footer-chandde/footer-chandde.component';
import { AdmissionFormComponent } from './chandde-admission-form/chandde-admission-form.component';
import { FilledInfoComponent } from './chandde-filled-info/chandde-filled-info.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    HeaderChanddeComponent,
    FooterChanddeComponent,
    AdmissionFormComponent,
    FilledInfoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
