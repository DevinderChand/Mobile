import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FooterChanddeComponent } from './footer-chandde.component';

describe('FooterChanddeComponent', () => {
  let component: FooterChanddeComponent;
  let fixture: ComponentFixture<FooterChanddeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [FooterChanddeComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(FooterChanddeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
