import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-footer-chandde',
  templateUrl: './footer-chandde.component.html',
  styleUrls: ['./footer-chandde.component.css']
})
export class FooterChanddeComponent {
  @Input() chanddeMyData: any;
}
