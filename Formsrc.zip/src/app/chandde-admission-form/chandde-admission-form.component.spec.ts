import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmissionFormComponent } from './chandde-admission-form.component';

describe('ChanddeAdmissionFormComponent', () => {
  let component: AdmissionFormComponent;
  let fixture: ComponentFixture<AdmissionFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AdmissionFormComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AdmissionFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
