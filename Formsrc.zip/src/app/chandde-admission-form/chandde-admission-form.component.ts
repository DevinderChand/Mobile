import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router'; // Import Router
import { ValidationService } from './validation.service';

@Component({
  selector: 'app-chandde-admission-form',
  templateUrl: './chandde-admission-form.component.html',
  styleUrls: ['./chandde-admission-form.component.css']
})
export class AdmissionFormComponent {
  form: FormGroup;
  campusList: string[] = ['Davis', 'Trafalgar', 'HMC'];
  departmentList: string[] = [
    'Faculty of Animation, Arts & Design (FAAD)',
    'Faculty of Applied Health & Community Studies (FAHCS)',
    'Faculty of Applied Science & Technology (FAST)',
    'Faculty of Humanities & Social Sciences (FHASS)',
    'Pilon School of Business (PSB)'
  ];

  constructor(private fb: FormBuilder, 
              private validationService: ValidationService,
              private router: Router) { // Inject Router
    this.form = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      birthDate: ['', Validators.compose([Validators.required, this.validationService.validateDate])],
      email: ['', Validators.compose([Validators.required, this.validationService.validateEmail])],
      contactNumber: [''],
      campus: [''],
      department: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.form.valid) {
      this.router.navigate(['/submit'], { state: { formData: this.form.value } });
    }
  }
  
  }

