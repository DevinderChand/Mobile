import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ValidationService {

  validateDate(selectedDate: any): { [key: string]: any } | null {
    if (!selectedDate) {
      return { 'required': true }; // Date should not be empty
    }

    const date = new Date(selectedDate);
    const today = new Date();

    if (isNaN(date.getTime())) {
      return { 'invalidDate': true }; // Date should be a valid date
    }

    if (date > today) {
      return { 'futureDate': true }; // Date of birth should not be today or in the future
    }

    return null; // Date is valid
  }

  validateEmail(email: any): { [key: string]: any } | null {
    if (!email) {
      return { 'required': true }; // Email is required
    }

    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    if (!emailRegex.test(email)) {
      return { 'invalidEmail': true }; // Email is not in valid format
    }

    return null; // Email is valid
  }
}
