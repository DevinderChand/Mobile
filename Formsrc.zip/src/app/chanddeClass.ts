export class FinalExam {
    LASTchandde!: string;
    FIRSTchandde!: string;
    EMAILchandde!: string;
    PROGRAMNAMEchandde!: string;
    LOGINchandde!: string;
  }
  