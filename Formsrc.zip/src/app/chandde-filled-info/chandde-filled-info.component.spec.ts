import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChanddeFilledInfoComponent } from './chandde-filled-info.component';

describe('ChanddeFilledInfoComponent', () => {
  let component: ChanddeFilledInfoComponent;
  let fixture: ComponentFixture<ChanddeFilledInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ChanddeFilledInfoComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ChanddeFilledInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
