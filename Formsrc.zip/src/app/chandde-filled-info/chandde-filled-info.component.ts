import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-chandde-filled-info',
  templateUrl: './chandde-filled-info.component.html',
  styleUrls: ['./chandde-filled-info.component.css']
})
export class FilledInfoComponent {
  formData: any;

  constructor(private route: ActivatedRoute) {
    this.route.paramMap.subscribe(params => {
      this.formData = history.state.formData;
    });
  }
}
