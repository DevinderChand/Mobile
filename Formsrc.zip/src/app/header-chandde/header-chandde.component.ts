import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-header-chandde',
  templateUrl: './header-chandde.component.html',
  styleUrls: ['./header-chandde.component.css']
})
export class HeaderChanddeComponent {
  @Input() chanddeMyData: any;
}
