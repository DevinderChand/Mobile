import { Component } from '@angular/core';
import { FinalExam } from './chanddeClass';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  chanddePersonal: FinalExam = {
    LASTchandde: 'Chand',
    FIRSTchandde: 'Devinder',
    EMAILchandde: 'chandde@sheridancollege.ca',
    PROGRAMNAMEchandde: 'Computer Programming',
    LOGINchandde: 'chandde'
  };
}
