import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MessageService } from '../message.service';
import covidData from '../../assets/data/ontario-covid-cases.json';
import vaccinesData2023Json from '../../assets/data/Ontario-vaccines2023.json';
import vaccinesData2024Json from '../../assets/data/Ontario-vaccines2024.json';

interface VaccinationData {
  "Previous Day Doses Administered": number;
  "Total Doses Administered": number;
  "Total Doses in Fully Vaccinated Individuals": number;
  "Total Individuals Fully Vaccinated": number;
}

@Component({
  selector: 'app-tab2',
  templateUrl: './tab2.page.html',
  styleUrls: ['./tab2.page.scss'],
})
export class Tab2Page implements OnInit {
  covidData: any;
  vaccinesData2023!: { month: string; data: VaccinationData; }[];
  vaccinesData2024!: { month: string; data: VaccinationData; }[];
  message: string = '';

  constructor(private router: Router, private messageService: MessageService) {}

  ngOnInit() {
    this.covidData = covidData;

    const vaccinesData2023 = vaccinesData2023Json as { [key: string]: VaccinationData };
    const vaccinesData2024 = vaccinesData2024Json as { [key: string]: VaccinationData };

    this.vaccinesData2023 = Object.keys(vaccinesData2023).map(month => ({
      month,
      data: vaccinesData2023[month]
    }));

    this.vaccinesData2024 = Object.keys(vaccinesData2024).map(month => ({
      month,
      data: vaccinesData2024[month]
    }));

    this.messageService.currentMessage.subscribe(message => this.message = message);
  }

  viewVaccinationData(year: number) {
    const data = year === 2023 ? this.vaccinesData2023 : this.vaccinesData2024;
    this.router.navigate(['/vaccine-data'], { state: { year, data } });
  }
}
