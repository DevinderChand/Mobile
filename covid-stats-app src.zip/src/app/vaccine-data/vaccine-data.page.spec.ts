import { ComponentFixture, TestBed } from '@angular/core/testing';
import { VaccineDataPage } from './vaccine-data.page';

describe('VaccineDataPage', () => {
  let component: VaccineDataPage;
  let fixture: ComponentFixture<VaccineDataPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(VaccineDataPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
