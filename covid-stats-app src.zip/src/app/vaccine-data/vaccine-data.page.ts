import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MessageService } from '../message.service';

@Component({
  selector: 'app-vaccine-data',
  templateUrl: './vaccine-data.page.html',
  styleUrls: ['./vaccine-data.page.scss'],
})
export class VaccineDataPage implements OnInit {
  year!: number;
  vaccinesData!: { month: string; data: any; }[];
  message: string = '';

  constructor(private router: Router, private messageService: MessageService) {
    const navigation = this.router.getCurrentNavigation();
    if (navigation?.extras?.state) {
      this.year = navigation.extras.state['year'];
      this.vaccinesData = navigation.extras.state['data'];
    }
  }

  ngOnInit() {}

  sendMessage() {
    this.messageService.changeMessage(this.message);
  }

  goBack() {
    this.router.navigate(['/tabs/tab2']);
  }
}
