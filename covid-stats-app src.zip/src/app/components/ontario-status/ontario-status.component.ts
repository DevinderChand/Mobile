import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DataService } from '../../data.service';

@Component({
  selector: 'app-ontario-status',
  templateUrl: './ontario-status.component.html',
  styleUrls: ['./ontario-status.component.scss'],
})
export class OntarioStatusComponent implements OnInit {
  ontarioCases: any;
  message!: string;

  constructor(private http: HttpClient, private dataService: DataService) {}

  ngOnInit() {
    this.loadOntarioCases();
    this.dataService.currentMessage.subscribe((message: string) => this.message = message);
  }

  loadOntarioCases() {

    this.http.get('assets/data/Ontario-covid-cases.json').subscribe(data => {
      this.ontarioCases = data;
    });
  }
}
