import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-canada-summary',
  templateUrl: './canada-summary.component.html',
  styleUrls: ['./canada-summary.component.scss'],
})
export class CanadaSummaryComponent implements OnInit {
  summaryData: any;

  constructor() {}

  ngOnInit() {

    this.summaryData = {
      newCasesToday: 527,
      totalCases: 4763972,
      activeCases: 7234,
      totalRecovered: 4684725,
      newDeathsToday: 5,
      totalDeaths: 71013,
      testsConductedToday: 37940,
      totalTestsConducted: 63578192,
      percentPositive: 7.5,
      peopleTestedPerMillion: 1653129,
    };
  }
}
